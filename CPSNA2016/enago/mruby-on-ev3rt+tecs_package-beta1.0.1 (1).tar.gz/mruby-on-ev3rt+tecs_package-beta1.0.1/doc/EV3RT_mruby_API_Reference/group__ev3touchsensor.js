var group__ev3touchsensor =
[
    [ "port", "group__ev3touchsensor.html#ga18141cc7c7997858eb8c73c52dab6869", [
      [ ":port1", "group__ev3touchsensor.html#gga18141cc7c7997858eb8c73c52dab6869a6ed151d83ba3df1e8d15ea2a2210178c", null ],
      [ ":port2", "group__ev3touchsensor.html#gga18141cc7c7997858eb8c73c52dab6869a9d524b63759bfbf608af2a9cce68bf17", null ],
      [ ":port3", "group__ev3touchsensor.html#gga18141cc7c7997858eb8c73c52dab6869a63e3918741010a8a1e229c3ecedd504c", null ],
      [ ":port4", "group__ev3touchsensor.html#gga18141cc7c7997858eb8c73c52dab6869a51984b8c0cf2e5fa5782c8b651b37cbf", null ],
    ] ],
    [ "initialize", "group__ev3touchsensor.html#touch_init", null ],
    [ "pressed?", "group__ev3touchsensor.html#ga0bd7ec7b7ac2fbaaa6cbe46eff3a829d", null ]
];