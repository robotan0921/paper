var searchData=
[
  ['sensor_5fport_5ft',['sensor_port_t',['../group__ev3sensor.html#ga18141cc7c7997858eb8c73c52dab6869',1,'ev3api_sensor.h']]],
  ['sensor_5ftype_5ft',['sensor_type_t',['../group__ev3sensor.html#ga089f166159fb19f10d81c65c1d8793a2',1,'ev3api_sensor.h']]],
  ['serial_5fport_5ft',['serial_port_t',['../group__ev3api-fs.html#gadfc0b70260f2ffd57afd8229806bd6bc',1,'ev3api_fs.h']]]
];
