var searchData=
[
  ['sensor_5fport_5ft',['sensor_port_t',['../group__ev3sensor.html#ga18141cc7c7997858eb8c73c52dab6869',1,'ev3api_sensor.h']]],
  ['sensor_5ftype_5ft',['sensor_type_t',['../group__ev3sensor.html#ga089f166159fb19f10d81c65c1d8793a2',1,'ev3api_sensor.h']]],
  ['serial_5fport_5ft',['serial_port_t',['../group__ev3api-fs.html#gadfc0b70260f2ffd57afd8229806bd6bc',1,'ev3api_fs.h']]],
  ['size',['size',['../structfileinfo__t.html#ab2c6b258f02add8fdf4cfc7c371dd772',1,'fileinfo_t']]],
  ['sound_5fmanual_5fstop',['SOUND_MANUAL_STOP',['../group__ev3api-speaker.html#ga167980fca3be2754a1a941610a73f3c9',1,'ev3api_speaker.h']]],
  ['stepspeed',['STEPSPEED',['../struct_s_t_e_p_s_p_e_e_d.html',1,'']]],
  ['stepsync',['STEPSYNC',['../struct_s_t_e_p_s_y_n_c.html',1,'']]]
];
