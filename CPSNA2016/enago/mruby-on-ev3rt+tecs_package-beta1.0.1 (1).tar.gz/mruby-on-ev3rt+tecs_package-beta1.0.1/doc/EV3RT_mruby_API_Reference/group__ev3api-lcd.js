var group__ev3api_lcd =
[
    [ "lcd color", "group__ev3api-lcd.html#ga29a41d6aaa6742b6ff7841023a7781fb", [
      [ ":wihte", "group__ev3api-lcd.html#gga29a41d6aaa6742b6ff7841023a7781fba29effcfea2a5e1a625020dd301f2512c", null ],
      [ ":black", "group__ev3api-lcd.html#gga29a41d6aaa6742b6ff7841023a7781fba2c3795c2a09dff8824a49df0bc66b467", null ]
    ] ],
    [ "lcd font", "group__ev3api-lcd.html#gacfa26216c22f39c9d2861015e37b1903", [
      [ ":small", "group__ev3api-lcd.html#ggacfa26216c22f39c9d2861015e37b1903a9fe43837bbb4586662d8c8a66ff6d358", null ],
      [ ":medium", "group__ev3api-lcd.html#ggacfa26216c22f39c9d2861015e37b1903a9724ff2a62acd060ff0df6797b2ac9e2", null ]
    ] ],
    [ "LCD.show_message_box", "group__ev3api-lcd.html#gaec36b70c4609aeeb40672df567c4a41a", null ],
    [ "LCD.print", "group__ev3api-lcd.html#ga9a557b39a31afd0fa6b8dc0c1aafedfd", null ],
    [ "LCD.error_puts", "group__ev3api-lcd.html#ga9d053062bacfad3421e077c45934ce62", null ],
    [ "LCD.puts", "group__ev3api-lcd.html#ga6d5385e6593c709c665d4a8366b6155a", null ],
    [ "LCD.draw_line", "group__ev3api-lcd.html#ga755de913d9fc48f816f2ed5c5076c400", null ],
    [ "LCD.draw", "group__ev3api-lcd.html#gad9949e40456ca903ee2bdcf8b8b8effe", null ],
    [ "LCD.fill_rect", "group__ev3api-lcd.html#gaeca9890ee5e82ad8fe48f8d50b3bd24f", null ],
    [ "LCD.font", "group__ev3api-lcd.html#font", null ]
];