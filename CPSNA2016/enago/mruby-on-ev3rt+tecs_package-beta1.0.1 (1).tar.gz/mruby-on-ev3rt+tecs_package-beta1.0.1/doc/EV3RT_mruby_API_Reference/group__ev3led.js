var group__ev3led =
[
    [ "led color", "group__ev3led.html#ga7866f9f79ea8cacbeb57995cdce3cb2f", [
      [ ":off", "group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fafc0ca8cc6cbe215fd3f1ae6d40255b40", null ],
      [ ":red", "group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fad80f13022b6d309268fadc7b1da89cb9", null ],
      [ ":green", "group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fa0ad916c7f80666dc88f6b5b22a72e742", null ],
      [ ":orange", "group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fa082cd0390f10e6458c4e2a8adf6594c5", null ]
    ] ],
    [ "LED.color=", "group__ev3led.html#gaa40eed1dd40c81573646f95ec8c427cb", null ],
    [ "LED.off","group__ev3led.html#LED.off", null ],
];
