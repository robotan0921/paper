var NAVTREEINDEX0 =
{
/*"annotated.html":[1,0],
"classes.html":[1,1],
"functions.html":[1,2,0],
"functions_vars.html":[1,2,1],*/

"index.html":[],
"modules.html":[0],
"pages.html":[],


"group__ev3api-brick.html":[0,0],
"group__ev3rt__battery.html":[0,0,0],
"group__ev3rt__battery.html#ga80698b59a9f94a751891cebf963cf319":[0,0,0,1],
"group__ev3rt__battery.html#gaa88ba0054f5215fa0ef1527afcab6ebc":[0,0,0,0],

"group__ev3button.html":[0,0,1],
"group__ev3button.html#ga58698096470ad567a785e82cd2514ced":[0,0,1,1],
"group__ev3button.html#ga7754652ebe470fb6cc5d30b4cd258660":[0,0,1,0],
"group__ev3button.html#gaf2da803506b62a1f3180e182f504ff80":[0,0,1,2],
"group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660a2f7db56ce29bb4a148cae5ab0198709a":[0,0,1,0,1],
"group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660a308e2dec294b93e1c691bacd5cd45266":[0,0,1,0,2],
"group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660a46cf6c1da23c500cd1369fa994f902fb":[0,0,1,0,5],
"group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660a4ef6f8a30edabae1ea534aa7c4f79199":[0,0,1,0,3],
"group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660ab42cc4bbdbed78b08763c32419fb5796":[0,0,1,0,4],
"group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660acc7c999423bde38a6b6156b77c4f194e":[0,0,1,0,0],
"group__ev3button.html#gga7754652ebe470fb6cc5d30b4cd258660af198627fc8492ff6a8bc7329f5d720da":[0,0,1,0,6],

"group__ev3led.html":[0,0,2],
"group__ev3led.html#ga7866f9f79ea8cacbeb57995cdce3cb2f":[0,0,2,0],
"group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fa082cd0390f10e6458c4e2a8adf6594c5":[0,0,2,0,3],
"group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fa0ad916c7f80666dc88f6b5b22a72e742":[0,0,2,0,2],
"group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fad80f13022b6d309268fadc7b1da89cb9":[0,0,2,0,1],
"group__ev3led.html#gga7866f9f79ea8cacbeb57995cdce3cb2fafc0ca8cc6cbe215fd3f1ae6d40255b40":[0,0,2,0,0],
"group__ev3led.html#gaa40eed1dd40c81573646f95ec8c427cb":[0,0,2,1],
"group__ev3led.html#LED.off":[0,0,2,2],


"group__ev3api-speaker.html":[0,0,3],
"group__ev3api-speaker.html#frequency":[0,0,3,0],

"group__ev3api-speaker.html#ga0260256515977d4f59895a893df1da59":[0,0,3,1],
"group__ev3api-speaker.html#gafdf8b7713aff9d314c0f5e2b95a23716":[0,0,3,2],



"group__ev3api-lcd.html":[0,1],
"group__ev3api-lcd.html#ga29a41d6aaa6742b6ff7841023a7781fb":[0,1,0],
"group__ev3api-lcd.html#gga29a41d6aaa6742b6ff7841023a7781fba29effcfea2a5e1a625020dd301f2512c":[0,1,0,0],
"group__ev3api-lcd.html#gga29a41d6aaa6742b6ff7841023a7781fba2c3795c2a09dff8824a49df0bc66b467":[0,1,0,1],
"group__ev3api-lcd.html#gacfa26216c22f39c9d2861015e37b1903":[0,1,1],
"group__ev3api-lcd.html#ggacfa26216c22f39c9d2861015e37b1903a9fe43837bbb4586662d8c8a66ff6d358":[0,1,1,0],
"group__ev3api-lcd.html#ggacfa26216c22f39c9d2861015e37b1903a9724ff2a62acd060ff0df6797b2ac9e2":[0,1,1,1],

"group__ev3api-lcd.html#gaec36b70c4609aeeb40672df567c4a41a":[0,1,2],
"group__ev3api-lcd.html#ga9a557b39a31afd0fa6b8dc0c1aafedfd":[0,1,3],
"group__ev3api-lcd.html#ga9d053062bacfad3421e077c45934ce62":[0,1,4],
"group__ev3api-lcd.html#ga6d5385e6593c709c665d4a8366b6155a":[0,1,5],
"group__ev3api-lcd.html#ga755de913d9fc48f816f2ed5c5076c400":[0,1,6],
"group__ev3api-lcd.html#gad9949e40456ca903ee2bdcf8b8b8effe":[0,1,7],
"group__ev3api-lcd.html#gaeca9890ee5e82ad8fe48f8d50b3bd24f":[0,1,8],
"group__ev3api-lcd.html#font":[0,1,9],

"group__ev3motor.html":[0,2],
"group__ev3motor.html#ga0f54b84f89f86be757f847d408a2f2f4":[0,2,0],
"group__ev3motor.html#gga0f54b84f89f86be757f847d408a2f2f4a45d2a35f4d83d7416273b9d6e5fb3c10":[0,2,0,0],
"group__ev3motor.html#gga0f54b84f89f86be757f847d408a2f2f4a64918ce114f44b89908009151b325ac6":[0,2,0,1],
"group__ev3motor.html#gga0f54b84f89f86be757f847d408a2f2f4a8077d672488fb19e0f864a65508b097e":[0,2,0,2],
"group__ev3motor.html#gga0f54b84f89f86be757f847d408a2f2f4aa1b994259795f86fdf26c690850202bf":[0,2,0,3],
"group__ev3motor.html#gga0f54b84f89f86be757f847d408a2f2f4a09134b8ce0f2f80e12555be3121bcc53":[0,2,0,4],

"group__ev3motor.html#ga5f0f3e75314ae11b050988a1ba3e2075":[0,2,1],
"group__ev3motor.html#gga5f0f3e75314ae11b050988a1ba3e2075aa17ca356ce12346af151348aae72761c":[0,2,1,0],
"group__ev3motor.html#gga5f0f3e75314ae11b050988a1ba3e2075ac2fe66302f9229b1360844843688f469":[0,2,1,1],

"group__ev3motor.html#ga25f485fbe38e4234b29e4f1e6a87bd3e":[0,2,2],
"group__ev3motor.html#ga0486d0a9d93975eb339f7b5e0afeb999":[0,2,3],
"group__ev3motor.html#ga67eb23319041faa1ef588c58d34f07e5":[0,2,4],
"group__ev3motor.html#ga6565458195489126606bd5144b5b400d":[0,2,5],
"group__ev3motor.html#ga08da6ad2f59add3e33d4d208b0cc98e8":[0,2,6],
"group__ev3motor.html#ga057b79d7b6ec476812df854133d28e86":[0,2,7],
"group__ev3motor.html#gaf5c96b6a7e3fdc7e13ba3466359294a0":[0,2,8],
/*"group__ev3motor.html#ga772dadf1354388584c36ba26f3baf7cf":[0,2,9],*/
"group__ev3motor.html#ga27585a7d658c0a5eec3ea4d7297c4e6b":[0,2,9],

"group__ev3api-rtos.html":[0,3],
"group__ev3api-rtos.html#ga7f51f241ca2b6283af7c5bd2ff843548":[0,3,0],
"group__ev3api-rtos.html#gaf57b142403f4c55309dafd0855a003e0":[0,3,1],
"group__ev3api-rtos.html#RTOS.msec":[0,3,2],


"group__ev3colorsensor.html":[0,4],
"group__ev3colorsensor.html#gaf11750614f023e665f98eca0b1f79c2f":[0,4,0],
/*"group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fa01ff12cf7ff51aef192abe6f9b7d8a4a":[0,4,0,0],*/
"group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fa2a9daf215a30f1c539ead18c66380fc1":[0,4,0,0],
"group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fa1340428efccb140dcbdb71aa6176f696":[0,4,0,1],
"group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2facfa9d8bbffc418447ed826f286abca02":[0,4,0,2],
"group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fab03862907066c68204ee9df1ee04aa29":[0,4,0,3],
"group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fa592503b9434c1e751a92f3fc536d7950":[0,4,0,4],
"group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fad47b4c240a0109970bb2a7fe3a07d3ec":[0,4,0,5],
"group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fa70b424bcf0a4a80c0a6f810d1cff20fe":[0,4,0,6],
"group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2faf916aa87dc882c0ebec3d6dc683f5147":[0,4,0,7],

"group__ev3colorsensor.html#ga18141cc7c7997858eb8c73c52dab6869":[0,4,1],
"group__ev3colorsensor.html#gga18141cc7c7997858eb8c73c52dab6869a51984b8c0cf2e5fa5782c8b651b37cbf":[0,4,1,3],
"group__ev3colorsensor.html#gga18141cc7c7997858eb8c73c52dab6869a63e3918741010a8a1e229c3ecedd504c":[0,4,1,2],
"group__ev3colorsensor.html#gga18141cc7c7997858eb8c73c52dab6869a6ed151d83ba3df1e8d15ea2a2210178c":[0,4,1,0],
"group__ev3colorsensor.html#gga18141cc7c7997858eb8c73c52dab6869a9d524b63759bfbf608af2a9cce68bf17":[0,4,1,1],
/*"group__ev3colorsensor.html#gga18141cc7c7997858eb8c73c52dab6869af1505cc881ba570b1260f73aea9bcd7d":[0,4,1,4],*/

"group__ev3colorsensor.html#ga554534f2f5a6ac558b29a9b01b5e8da3":[0,4,2],
"group__ev3colorsensor.html#ga11104447594453531fc2c7e268e111be":[0,4,3],
"group__ev3colorsensor.html#ga776b35d98fd73550278e27ee39a3d3aa":[0,4,4],
"group__ev3colorsensor.html#ga6f0760f8a0781fd5397f3365c6d6ac87":[0,4,5],

"group__ev3gyrosensor.html":[0,5],
"group__ev3gyrosensor.html#ga18141cc7c7997858eb8c73c52dab6869":[0,5,0],
"group__ev3gyrosensor.html#gga18141cc7c7997858eb8c73c52dab6869a6ed151d83ba3df1e8d15ea2a2210178c":[0,5,0,0],
"group__ev3gyrosensor.html#gga18141cc7c7997858eb8c73c52dab6869a9d524b63759bfbf608af2a9cce68bf17":[0,5,0,1],
"group__ev3gyrosensor.html#gga18141cc7c7997858eb8c73c52dab6869a63e3918741010a8a1e229c3ecedd504c":[0,5,0,2],
"group__ev3gyrosensor.html#gga18141cc7c7997858eb8c73c52dab6869a51984b8c0cf2e5fa5782c8b651b37cbf":[0,5,0,3],
"group__ev3gyrosensor.html#gyro_init":[0,5,1],
"group__ev3gyrosensor.html#gaa679135221ab97ead4d35a7819c228c3":[0,5,2],
"group__ev3gyrosensor.html#ga5853577f47d1006fff6f050257fca384":[0,5,3],
"group__ev3gyrosensor.html#ga3ea1432e34aa420afe5444c6a93c4f86":[0,5,4],
"group__ev3gyrosensor.html#gyro_calib":[0,5,5],

"group__ev3ultrasonicsensor.html":[0,6],
"group__ev3ultrasonicsensor.html#ga18141cc7c7997858eb8c73c52dab6869":[0,6,0],
"group__ev3ultrasonicsensor.html#gga18141cc7c7997858eb8c73c52dab6869a6ed151d83ba3df1e8d15ea2a2210178c":[0,6,0,0],
"group__ev3ultrasonicsensor.html#gga18141cc7c7997858eb8c73c52dab6869a9d524b63759bfbf608af2a9cce68bf17":[0,6,0,1],
"group__ev3ultrasonicsensor.html#gga18141cc7c7997858eb8c73c52dab6869a63e3918741010a8a1e229c3ecedd504c":[0,6,0,2],
"group__ev3ultrasonicsensor.html#gga18141cc7c7997858eb8c73c52dab6869a51984b8c0cf2e5fa5782c8b651b37cbf":[0,6,0,3],
"group__ev3ultrasonicsensor.html#ultr_init":[0,6,1],
"group__ev3ultrasonicsensor.html#ga956536aaab7677c2b512b2d3bd4e498f":[0,6,2],
"group__ev3ultrasonicsensor.html#ga719db52bd7f8ad451d4d4b5bbad7706e":[0,6,3],

"group__ev3touchsensor.html":[0,7],
"group__ev3touchsensor.html#ga18141cc7c7997858eb8c73c52dab6869":[0,7,0],
"group__ev3touchsensor.html#gga18141cc7c7997858eb8c73c52dab6869a6ed151d83ba3df1e8d15ea2a2210178c":[0,7,0,0],
"group__ev3touchsensor.html#gga18141cc7c7997858eb8c73c52dab6869a9d524b63759bfbf608af2a9cce68bf17":[0,7,0,1],
"group__ev3touchsensor.html#gga18141cc7c7997858eb8c73c52dab6869a63e3918741010a8a1e229c3ecedd504c":[0,7,0,2],
"group__ev3touchsensor.html#gga18141cc7c7997858eb8c73c52dab6869a51984b8c0cf2e5fa5782c8b651b37cbf":[0,7,0,3],
"group__ev3touchsensor.html#touch_init":[0,7,1],
"group__ev3touchsensor.html#ga0bd7ec7b7ac2fbaaa6cbe46eff3a829d":[0,7,2]

};
