var group__ev3colorsensor =
[
    [ "color", "group__ev3colorsensor.html#gaf11750614f023e665f98eca0b1f79c2f", [
      [ ":black", "group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fa2a9daf215a30f1c539ead18c66380fc1", null ],
      [ ":blue", "group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fa1340428efccb140dcbdb71aa6176f696", null ],
      [ ":green", "group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2facfa9d8bbffc418447ed826f286abca02", null ],
      [ ":yellow", "group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fab03862907066c68204ee9df1ee04aa29", null ],
      [ ":red", "group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fa592503b9434c1e751a92f3fc536d7950", null ],
      [ ":white", "group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fad47b4c240a0109970bb2a7fe3a07d3ec", null ],
      [ ":brown", "group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2fa70b424bcf0a4a80c0a6f810d1cff20fe", null ],
      [ ":none", "group__ev3colorsensor.html#ggaf11750614f023e665f98eca0b1f79c2faf916aa87dc882c0ebec3d6dc683f5147", null ]
    ] ],
    [ "port", "group__ev3colorsensor.html#ga18141cc7c7997858eb8c73c52dab6869", [
      [ ":port1", "group__ev3colorsensor.html#gga18141cc7c7997858eb8c73c52dab6869a6ed151d83ba3df1e8d15ea2a2210178c", null ],
      [ ":port2", "group__ev3colorsensor.html#gga18141cc7c7997858eb8c73c52dab6869a9d524b63759bfbf608af2a9cce68bf17", null ],
      [ ":port3", "group__ev3colorsensor.html#gga18141cc7c7997858eb8c73c52dab6869a63e3918741010a8a1e229c3ecedd504c", null ],
      [ ":port4", "group__ev3colorsensor.html#gga18141cc7c7997858eb8c73c52dab6869a51984b8c0cf2e5fa5782c8b651b37cbf", null ],
    ] ],
    [ "initialize", "group__ev3colorsensor.html#ga554534f2f5a6ac558b29a9b01b5e8da3", null ],
    [ "ambient", "group__ev3colorsensor.html#ga11104447594453531fc2c7e268e111be", null ],
    [ "color", "group__ev3colorsensor.html#ga776b35d98fd73550278e27ee39a3d3aa", null ],
    [ "reflect", "group__ev3colorsensor.html#ga6f0760f8a0781fd5397f3365c6d6ac87", null ]
];