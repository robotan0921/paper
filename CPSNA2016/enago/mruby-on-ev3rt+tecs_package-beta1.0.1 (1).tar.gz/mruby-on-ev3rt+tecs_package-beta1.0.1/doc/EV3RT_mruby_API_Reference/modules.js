﻿var modules =
[
    [ "EV3本体機能", "group__ev3api-brick.html", "group__ev3api-brick" ],
/*    [ "ファイルシステム", "group__ev3api-fs.html", "group__ev3api-fs" ],*/
    [ "LCD", "group__ev3api-lcd.html", "group__ev3api-lcd" ],
    [ "サーボモータ", "group__ev3motor.html", "group__ev3motor" ],
    [ "RTOS機能", "group__ev3api-rtos.html", "group__ev3api-rtos" ],
    [ "カラーセンサ", "group__ev3colorsensor.html", "group__ev3colorsensor" ],
    [ "ジャイロセンサ", "group__ev3gyrosensor.html", "group__ev3gyrosensor" ],
    [ "超音波センサ", "group__ev3ultrasonicsensor.html", "group__ev3ultrasonicsensor" ],
    [ "タッチセンサ", "group__ev3touchsensor.html", "group__ev3touchsensor" ]
];