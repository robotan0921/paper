var group__ev3ultrasonicsensor =
[
    [ "port", "group__ev3ultrasonicsensor.html#ga18141cc7c7997858eb8c73c52dab6869", [
      [ ":port1", "group__ev3ultrasonicsensor.html#gga18141cc7c7997858eb8c73c52dab6869a6ed151d83ba3df1e8d15ea2a2210178c", null ],
      [ ":port2", "group__ev3ultrasonicsensor.html#gga18141cc7c7997858eb8c73c52dab6869a9d524b63759bfbf608af2a9cce68bf17", null ],
      [ ":port3", "group__ev3ultrasonicsensor.html#gga18141cc7c7997858eb8c73c52dab6869a63e3918741010a8a1e229c3ecedd504c", null ],
      [ ":port4", "group__ev3ultrasonicsensor.html#gga18141cc7c7997858eb8c73c52dab6869a51984b8c0cf2e5fa5782c8b651b37cbf", null ],
    ] ],
    [ "initialize", "group__ev3ultrasonicsensor.html#ultr_init", null ],
    [ "distance", "group__ev3ultrasonicsensor.html#ga956536aaab7677c2b512b2d3bd4e498f", null ],
    [ "listen", "group__ev3ultrasonicsensor.html#ga719db52bd7f8ad451d4d4b5bbad7706e", null ]
];