var group__ev3gyrosensor =
[
    [ "port", "group__ev3gyrosensor.html#ga18141cc7c7997858eb8c73c52dab6869", [
      [ ":port1", "group__ev3gyrosensor.html#gga18141cc7c7997858eb8c73c52dab6869a6ed151d83ba3df1e8d15ea2a2210178c", null ],
      [ ":port2", "group__ev3gyrosensor.html#gga18141cc7c7997858eb8c73c52dab6869a9d524b63759bfbf608af2a9cce68bf17", null ],
      [ ":port3", "group__ev3gyrosensor.html#gga18141cc7c7997858eb8c73c52dab6869a63e3918741010a8a1e229c3ecedd504c", null ],
      [ ":port4", "group__ev3gyrosensor.html#gga18141cc7c7997858eb8c73c52dab6869a51984b8c0cf2e5fa5782c8b651b37cbf", null ],
    ] ],
    [ "initialize", "group__ev3gyrosensor.html#gyro_init", null ],
    [ "angle", "group__ev3gyrosensor.html#gaa679135221ab97ead4d35a7819c228c3", null ],
    [ "rate", "group__ev3gyrosensor.html#ga5853577f47d1006fff6f050257fca384", null ],
    [ "reset", "group__ev3gyrosensor.html#ga3ea1432e34aa420afe5444c6a93c4f86", null ],
    [ "calibrate", "group__ev3gyrosensor.html#gyro_calib", null ]
];