var struct_s_t_e_p_s_p_e_e_d =
[
    [ "Brake", "struct_s_t_e_p_s_p_e_e_d.html#a26d25e195c44ed33132d5a195b241e69", null ],
    [ "Cmd", "struct_s_t_e_p_s_p_e_e_d.html#a6d0b94f04ea1dc2e87c796f7c6652eec", null ],
    [ "Nos", "struct_s_t_e_p_s_p_e_e_d.html#a4a9b4b9420f11eb1ae417c76efc26b48", null ],
    [ "Speed", "struct_s_t_e_p_s_p_e_e_d.html#a6038fc186d48ad57b0fc73782ffe9adf", null ],
    [ "Step1", "struct_s_t_e_p_s_p_e_e_d.html#ab9b5c17a2dd1ae3c0f53b558d8c8d6b5", null ],
    [ "Step2", "struct_s_t_e_p_s_p_e_e_d.html#a1892a12a568ffa6b45902969c67774eb", null ],
    [ "Step3", "struct_s_t_e_p_s_p_e_e_d.html#af67736edc2f79f13220a9667012b0112", null ]
];