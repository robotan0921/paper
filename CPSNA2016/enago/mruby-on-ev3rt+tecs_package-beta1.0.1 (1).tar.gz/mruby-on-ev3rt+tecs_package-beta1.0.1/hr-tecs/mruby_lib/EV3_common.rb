$port_hash=Hash.new
